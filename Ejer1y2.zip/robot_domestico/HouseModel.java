import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

import jason.environment.grid.GridWorldModel;
import jason.environment.grid.Location;

/** class that implements the Model of Domestic Robot application */
public class HouseModel extends GridWorldModel {

    // Constantes para los elementos del grid
    public static final int FRIDGE = 16;
    public static final int COUCH = 32;
    public static final int DELIVERY = 64;
    public static final int BIN = 128;
    public static final int TRASH = 256;
    //public static final int OBSTACULE = 512;

    // Tamaño del grid
    public static final int GSize = 10;

    // Map relacionando el nombre de los agentes con su id
    Map<String, Integer> agents = 
        Map.of(
            "rmayordomo",0,
            "rlimpiador", 1,
            "rbasurero", 2,
            "rpedidos", 3,
            "owner",4
        );

    // Variables de frigorifico abierto o cerrado
    boolean fridgeOpenMayordomo = false;
    boolean fridgeOpenOwner = false;

    // Variables de posesión de una cerveza
    boolean carryingBeerMayordomo = false;
    boolean carryingBeerOwner = false;

    // Número de sorbos que ha hecho el owner
    int sipCount = 0;

    // Cervezas disponibles
    int availableBeers  = 3;

    // Cervezas en la zona de entrega
    int deliveryBeers = 0;

    // Número de cervezas que lleva el robot de pedidos
    int rpedidosBeers = 0;

    // Número de latas que hay en el cubo de basura
    int cansInTrash = 0;
    
    // Posiciones de los elementos del entorno
    Location lFridge = new Location(0,0);
    Location lDelivery = new Location(0, GSize-1);
    Location lBin = new Location(GSize-1, 0);
    Location lCouch = new Location(GSize-1,GSize-1);

    // Posiciones originales de los agentes
    Location lRMayordomo = new Location(GSize/2, GSize/2);
    Location lRLimpiador = new Location(GSize/2, 0);
    Location lRBasurero = new Location(GSize-1, GSize/2-2);
    Location lRPedidos = new Location(GSize/2-2, GSize-1);
    Location lOwner = new Location(GSize-1,GSize-1);

    // ArrayList de posiciones de la basura
    ArrayList<Location> lTrash 
        = new ArrayList<>();

    /*
    // ArrayList de posiciones de los obstaculos
    ArrayList<Location> lObstacules 
        = new ArrayList<>(Arrays.asList(
            new Location(3,4),
            new Location(2,1),
            new Location(7,4),
            new Location(5,8)
        )
    );
    */
    
    // Arrays de posiciones permitidas para la colocación de los agentes

    // Posiciones permitidas del frigorifico
    ArrayList<Location> lFridgePositions 
        = new ArrayList<>(Arrays.asList(
            new Location(lFridge.x+1, lFridge.y+1),
            new Location(lFridge.x+1, lFridge.y),
            new Location(lFridge.x, lFridge.y+1)
        ));
    
    // Posiciones permitidas del sillón
    ArrayList<Location> lCouchPositions
        = new ArrayList<>(Arrays.asList(
            new Location(lCouch.x-1, lCouch.y-1),
            new Location(lCouch.x-1, lCouch.y),
            new Location(lCouch.x, lCouch.y-1)
        ));

    // Posiciones permitidas de la zona de entrega
    ArrayList<Location> lDeliveryPositions
        = new ArrayList<>(Arrays.asList(
            new Location(lDelivery.x+1, lDelivery.y),
            new Location(lDelivery.x, lDelivery.y-1),
            new Location(lDelivery.x+1, lDelivery.y-1)
        ));
    
    // Posiciones permitidas del cubo de basura
    ArrayList<Location> lBinPositions
        = new ArrayList<>(Arrays.asList(
            new Location(lBin.x-1, lBin.y),
            new Location(lBin.x-1, lBin.y+1),
            new Location(lBin.x, lBin.y+1)
        ));

    public HouseModel() {
        // Creación del grid con el tamaño definido en GSize
        // Número de agentes móviles: 5
        super(GSize, GSize, 5);

        // Añadido de posiciones iniciales para los agentes (móviles)
        setAgPos(agents.get("rmayordomo"), lRMayordomo);
        setAgPos(agents.get("rlimpiador"), lRLimpiador);
        setAgPos(agents.get("rbasurero"), lRBasurero);
        setAgPos(agents.get("rpedidos"), lRPedidos);
        setAgPos(agents.get("owner"), lOwner);

        // Añadido de posiciones para los elementos del entorno (no móviles)
        add(FRIDGE, lFridge);
        add(DELIVERY, lDelivery);
        add(BIN, lBin);
        add(COUCH, lCouch);
        /*
        for(int i = 0; i<lObstacules.size();i++){
            add(OBSTACULE, lObstacules.get(i));
        } 
        */
    }

    // Abrir frigorífico
    boolean openFridge(String ag) {
        if (!fridgeOpenMayordomo && ag.equals("rmayordomo")) {
            fridgeOpenMayordomo = true;   
        } else if(!fridgeOpenOwner && ag.equals("owner")){
            fridgeOpenOwner = true;
        } else {
            return false;
        }

        return true;
    }

    // Cerrar frigorífico
    boolean closeFridge(String ag) {
        if (fridgeOpenMayordomo && ag.equals("rmayordomo")) {
            fridgeOpenMayordomo = false;   
        } else if(fridgeOpenOwner && ag.equals("owner")){
            fridgeOpenOwner = false;
        } else {
            return false;
        }

        return true;
    }

    // Movimiento de los agentes por el entorno
    boolean moveTowards(String ag, Location dest) {

        int nAg = this.agents.get(ag);
        Location lAgent = getAgPos(nAg);
        
        if      (lAgent.x < dest.x)   lAgent.x++;
        else if (lAgent.x > dest.x)   lAgent.x--;
         if (lAgent.y < dest.y)        lAgent.y++;
        else if (lAgent.y > dest.y)   lAgent.y--;

        setAgPos(nAg, lAgent);

        for (int agent: this.agents.values()) {
            setAgPos(agent, getAgPos(agent));
        }

        /*
        if (view != null) {
            view.update(lFridge.x,lFridge.y);
            view.update(lOwner.x,lOwner.y);
            view.update(lDelivery.x, lDelivery.y);
            view.update(lBin.x, lBin.y);
        }
        */
        
        return true;
    }

    // Coger cerveza del frigorifico
    boolean getBeer(String ag) {
        if (availableBeers > 0) {
            if(fridgeOpenMayordomo && ag.equals("rmayordomo") && !carryingBeerMayordomo){
                carryingBeerMayordomo = true;
            } else if(fridgeOpenOwner && ag.equals("owner") && !carryingBeerOwner){
                carryingBeerOwner = true;
            }
            
            availableBeers--;
            
            if (view != null) view.update(lFridge.x,lFridge.y);
            return true;
        } else {
            return false;
        }
    }

    // Meter cervezas en la zona de entrega
    boolean addBeerDelivery(int n) {
        deliveryBeers += n;
        if (view != null) view.update(lDelivery.x,lDelivery.y);
        return true;
    }

    boolean addBeerFridge(int n) {
        if(rpedidosBeers > 0){
            rpedidosBeers-=n;
            availableBeers+=n;
            if (view != null) view.update(lFridge.x,lFridge.y);
            return true;
        }
        else{
            return false;
        }
    }

    // Entrega de cerveza al owner
    boolean handInBeer(String ag) {
        if(ag.equals("rmayordomo") && carryingBeerMayordomo){
            carryingBeerMayordomo = false;
        } else if(ag.equals("owner") && carryingBeerOwner){
            carryingBeerOwner = false;
        } else{
            return false;
        }
            
        sipCount = 10;
            
        if(view != null){
            Location lAgent = getAgPos(this.agents.get("owner"));
            view.update(lAgent.x,lAgent.y);
        }
            
        return true;
    }

    // Sorver cerveza
    boolean sipBeer() {
        if (sipCount > 0) {
            sipCount--;
            if(view != null){
                Location lAgent = getAgPos(this.agents.get("owner"));
                view.update(lAgent.x,lAgent.y);
            }
            return true;
        } else {
            return false;
        }
    }

    // desechar la basura
    boolean desechar(){
        cansInTrash++;
        if (view != null) view.update(lBin.x,lBin.y);
        return true; 
    }

    // Vacía el cubo de basura
    boolean vaciarPapelera(){
        if(cansInTrash > 0){
            cansInTrash = 0;
          
        } 
		  if (view != null) view.update(lBin.x,lBin.y);
            return true;
    }


    // Desperdigar la basura que tira el owner por el entorno
    boolean generateTrash() {
        Location location;
        do{
            int x = (int) (Math.random()*(GSize-1));
            int y = (int) (Math.random()*(GSize-1));
            location = new Location(x, y);
        }while(
            //lObstacules.contains(location) &&
            location.equals(lBin) &&
            location.equals(lFridge) &&
            location.equals(lCouch) &&
            location.equals(lDelivery) 
        );
        
        add(TRASH, location);
        lTrash.add(location);
        return true;

    }


    // Recoger la basura que se encuentra en el entorno
    boolean pickTrash() {
        Location r1 = getAgPos(agents.get("rlimpiador"));

        if (hasObject(TRASH, r1)) {
            if(lTrash.contains(r1)){
                lTrash.remove(lTrash.indexOf(r1));

            }
            remove(TRASH, r1);
			return true;
        }
		return false;
    }

    // Recoger las cervezas del punto de recogida
    public boolean getDelivery(int n) {
        if (deliveryBeers > 0) {
            deliveryBeers-=n;
            rpedidosBeers+=n;
            if(view != null){
                view.update(lDelivery.x,lDelivery.y);
            }
            return true;
        } else {
            return false;
        }
    }
}
